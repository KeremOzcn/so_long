/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   server.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kozcan <kozcan@student.42istanbul.com.t    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/25 15:40:16 by kozcan            #+#    #+#             */
/*   Updated: 2025/02/25 15:40:18 by kozcan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minitalk.h"

void	error_mes(int error_num, char *err)
{
	ft_printf("excited with (%d): %s\n", error_num, err);
	exit(error_num);
}

void	take_char(int sig)
{
	static char	str;
	static int	check_byte;

	if (sig == SIGUSR1)
		str = str | 1;
	check_byte ++;
	if (check_byte == 7)
	{
		ft_printf("%c", str);
		str = 0;
		check_byte = 0;
	}
	else
		str <<= 1;
}

int	main(int argc, char **argv)
{
	if (argc != 1)
		error_mes(0, ERR_TOO_MANY_ARG);
	(void)argv;
	ft_printf("procces_id -> %d\n", getpid());
	signal(SIGUSR1, take_char);
	signal(SIGUSR2, take_char);
	while (1)
		pause();
}
