/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   client.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kozcan <kozcan@student.42istanbul.com.t    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/25 15:40:46 by kozcan            #+#    #+#             */
/*   Updated: 2025/02/25 15:40:48 by kozcan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minitalk.h"

void	error_mes(int error_num, char *err)
{
	ft_printf("excited with (%d): %s\n", error_num, err);
	exit(error_num);
}

void	send_char(int pid, char *str)
{
	int	i;
	int	c;

	while (*str)
	{
		i = 7;
		c = *str++;
		while (i--)
		{
			if (c >> i & 1)
			{
				if ((kill(pid, SIGUSR1)) == -1)
					error_mes(0, ERR_KILL);
			}
			else
				if ((kill(pid, SIGUSR2)) == -1)
					error_mes(0, ERR_KILL);
			usleep(100);
		}
	}
}

int	main(int argc, char **argv)
{
	if (argc < 3)
		error_mes(0, ERR_ARGUMENT);
	else if (argc > 3)
		error_mes(0, ERR_TOO_MANY_ARG);
	send_char(ft_atoi(argv[1]), argv[2]);
	return (0);
}
