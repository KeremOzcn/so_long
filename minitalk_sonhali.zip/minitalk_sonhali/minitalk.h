/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minitalk.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kozcan <kozcan@student.42istanbul.com.t    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/25 15:40:23 by kozcan            #+#    #+#             */
/*   Updated: 2025/02/25 15:40:31 by kozcan           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINITALK_H
# define MINITALK_H

# include "ft_printf/ft_printf.h"
# include "libft/libft.h"
# include <signal.h>
# include <unistd.h>

# define ERR_KILL "kill error, signal cannot be sent"
# define ERR_TOO_MANY_ARG "too many arguments"
# define ERR_ARGUMENT "there have to be at least 2 arguments"
# define ERR_SIGACTION "sigaction error"
# define ERR_PID "pid is not valid"

#endif 